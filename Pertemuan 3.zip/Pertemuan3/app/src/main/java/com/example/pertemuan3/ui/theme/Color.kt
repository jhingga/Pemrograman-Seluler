package com.example.pertemuan3.ui.theme

import androidx.compose.ui.graphics.Color

val Blue80 = Color(0xFF82B1FF)
val BlueGrey80 = Color(0xFFB0BEC5)
val Green80 = Color(0xFFA5D6A7)

val Blue40 = Color(0xFF2962FF)
val BlueGrey40 = Color(0xFF455A64)
val Green40 = Color(0xFF388E3C)
